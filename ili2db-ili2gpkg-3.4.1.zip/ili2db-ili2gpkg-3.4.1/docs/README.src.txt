ili2ora - INTERLIS 2-loader for oracle

License
ili2ora is licensed under the LGPL (Lesser GNU Public License).

Status
ili2ora is in beta/transition state.

System Configuration
In order to compile ili2ora, a JAVA software development kit (JDK) version 1.6 or a more recent version must be installed on your system.
A free version of the JAVA software development kit (JDK) is available at the website http://java.sun.com/j2se/.
Also required is the build tool ant. Download it from http://ant.apache.org and install it as documented there.

Installation
To install ili2ora, choose a directory and extract the distribution file there. 

How to compile it?
To compile ili2ora, change to the newly created directory and enter the following command at the commandline prompt

ant jar

To build a binary distribution, use

ant bindist

Comments/Suggestions
Please send comments to ce@eisenhutinformatik.ch.

