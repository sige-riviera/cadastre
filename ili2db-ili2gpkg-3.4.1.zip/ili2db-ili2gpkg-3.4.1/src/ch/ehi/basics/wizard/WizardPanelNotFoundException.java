package ch.ehi.basics.wizard;

import java.io.*;

public class WizardPanelNotFoundException extends RuntimeException {
        
    public WizardPanelNotFoundException() {
        super();
    }
     
    
}