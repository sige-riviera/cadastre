package ch.ehi.ili2db.mapping;

public class IliMetaAttrNames {
	public static final String METAATTR_MAPPING="ili2db.mapping"; 
	public static final String METAATTR_MAPPING_MULTISURFACE="MultiSurface"; 
	
	private IliMetaAttrNames() {
	}

}
