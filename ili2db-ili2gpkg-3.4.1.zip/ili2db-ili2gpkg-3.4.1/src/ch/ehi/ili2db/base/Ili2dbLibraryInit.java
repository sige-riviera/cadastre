package ch.ehi.ili2db.base;

public interface Ili2dbLibraryInit {
	public void init();
	public void end();
}
