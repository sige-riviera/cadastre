package ch.ehi.ili2db.base;

public interface DbUrlConverter {
	public String makeUrl(ch.ehi.ili2db.gui.Config config);
}
