package ch.ehi.ili2db.base;

public interface GeodbConnection {

}
