package ch.ehi.ili2db.base;

public class Ili2dbException extends Exception {

	public Ili2dbException() {
	}

	public Ili2dbException(String arg0) {
		super(arg0);
	}

	public Ili2dbException(Throwable arg0) {
		super(arg0);
	}

	public Ili2dbException(String arg0, Throwable arg1) {
		super(arg0, arg1);
	}

}
