package ch.ehi.ili2db.base;

public class Ili2dbLibraryInitNull implements Ili2dbLibraryInit {

	public void end() {
	}

	public void init() {
	}

}
